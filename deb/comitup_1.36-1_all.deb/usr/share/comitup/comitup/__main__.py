from . import comitup

comitup.main()
