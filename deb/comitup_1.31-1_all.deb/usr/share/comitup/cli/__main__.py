from . import comitupcli

comitupcli.main()
