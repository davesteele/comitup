
This repository supports the build of a debian package which installs Dave
Steele's gpg key for use with his personal repositories, adding apt sources entries referring to that key.
