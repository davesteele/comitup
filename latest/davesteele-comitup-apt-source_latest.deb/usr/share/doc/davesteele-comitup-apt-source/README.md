
This repository supports the build of a debian package which installs Dave
Steele's gpg key for use with his personal repositories, adding apt sources entries referring to that key.

Note that the GPG key installed by this package is on the [Debian
Keyring](https://salsa.debian.org/debian-keyring/keyring/-/blob/master/debian-keyring-gpg/0x8A3171EF366150CE).
You probably already have a trust relationship with it.
